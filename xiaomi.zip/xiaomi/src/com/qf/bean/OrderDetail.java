package com.qf.bean;

import java.util.List;

public class OrderDetail {
	//��� ������ϸ��Ϣ ʵ��
	//���� ���� �� address�� orderDetail�� goods�� ͨ��pid����
	
	private Order order;
	private Address address;
	private List<BuyGoods> list;
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public List<BuyGoods> getList() {
		return list;
	}
	public void setList(List<BuyGoods> list) {
		this.list = list;
	}
	public OrderDetail(Order order, Address address, List<BuyGoods> list) {
		super();
		this.order = order;
		this.address = address;
		this.list = list;
	}
	public OrderDetail() {
		super();
	}
	@Override
	public String toString() {
		return "OrderDetail [order=" + order + ", address=" + address + ", list=" + list + "]";
	}
	
}
