package com.qf.service.impl;

import java.util.List;

import com.qf.bean.Goods;
import com.qf.bean.GoodsType;
import com.qf.dao.GoodsDao;
import com.qf.dao.impl.GoodsDaoImpl;
import com.qf.service.GoodsService;

public class GoodsServiceImpl implements GoodsService{
	GoodsDao dao = new GoodsDaoImpl();
	@Override
	public List<GoodsType> getGoodsTypeList() {
		// TODO Auto-generated method stub
		return dao.getGoodsTypeList();
	}
	@Override
	public boolean addGoodsType(GoodsType gtype) {
		// TODO Auto-generated method stub
		return dao.addGoodsType(gtype);
	}
	@Override
	public List<Goods> getGoodsList() {
		// TODO Auto-generated method stub
		return dao.getGoodsList();
	}
	@Override
	public boolean addGoods(Goods goods) {
		// TODO Auto-generated method stub
		return dao.addGoods(goods);
	}
	@Override
	public List<GoodsType> getGoodsTypeAjaxList() {
		// TODO Auto-generated method stub
		return dao.getGoodsTypeAjaxList();
	}
	@Override
	public List<Goods> getGoodsListByTypeId(int typeId) {
		// TODO Auto-generated method stub
		return dao.getGoodsListByTypeId(typeId);
	}
	@Override
	public Goods getGoodsById(int goodsId) {
		// TODO Auto-generated method stub
		return dao.getGoodsById(goodsId);
	}

}
