package com.qf.service.impl;

import java.util.List;

import com.qf.bean.Address;
import com.qf.bean.User;
import com.qf.dao.UserDao;
import com.qf.dao.impl.UserDaoImpl;
import com.qf.service.UserService;

public class UserServiceImpl implements UserService {
	UserDao dao = new UserDaoImpl();
	@Override
	public boolean addUser(User user) {
		
		return dao.addUser(user);
	}
	@Override
	public boolean activate(String email, String code) {
		// TODO Auto-generated method stub
		return dao.activate(email,code);
	}
	@Override
	public User checkName(String username) {
		// TODO Auto-generated method stub
		return dao.checkName(username);
	}
	@Override
	public List<Address> getAddressList(int uid) {
		// TODO Auto-generated method stub
		return dao.getAddressList(uid);
	}
	@Override
	public boolean addAddress(Address address) {
		// TODO Auto-generated method stub
		return dao.addAddress(address);
	}
	@Override
	public boolean deleteAddress(int id) {
		// TODO Auto-generated method stub
		return dao.deleteAddress(id);
	}
	@Override
	public boolean updateAddress(Address address) {
		// TODO Auto-generated method stub
		return dao.updateAddress(address);
	}
	@Override
	public boolean defaultAddress(int addressId, int userId) {
		// �������� 
		//��һ�� �� ���� userId ��ѯ address �� ��ȡ�����û������е�ַ��Ϣ �� ��Щ��ַ��Ϣ ȫ������levelΪ 0
		List<Address> list = dao.getAddressList(userId);
		for(Address addr:list){
			dao.defaultAddress(addr.getId(), 0);
		}
		//�ڶ��� ����addressId �� ָ������һ����¼ level����Ϊ1
		
		return dao.defaultAddress(addressId, 1);
	}
	@Override
	public User findAdmin(String username) {
		// TODO Auto-generated method stub
		return dao.findAdmin(username);
	}
	@Override
	public List<User> getUserList() {
		// TODO Auto-generated method stub
		return dao.getUserList();
	}
	@Override
	public boolean deleteUser(int id) {
		// TODO Auto-generated method stub
		return dao.deleteUser(id);
	}
	@Override
	public List<User> searchUserList(String username, String gender) {
		// TODO Auto-generated method stub
		return dao.searchUserList(username, gender);
	}
	@Override
	public Address getSingle(int aid) {
		// TODO Auto-generated method stub
		return dao.getSingle(aid);
	}

}
