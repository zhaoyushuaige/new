package com.qf.servlet.order;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.bean.Order;
import com.qf.bean.User;
import com.qf.service.OrderService;
import com.qf.service.impl.OrderServiceImpl;
@WebServlet("/getOrderList")
public class GetOrderList extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User user = (User)req.getSession().getAttribute("loginUser");
		if(user!=null){
			OrderService service = new OrderServiceImpl();
			List<Order> list = service.getOrderList(user.getId());
			req.getSession().setAttribute("orderList", list);
			resp.sendRedirect("orderList.jsp");
		}else{
			resp.sendRedirect("login.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
}
