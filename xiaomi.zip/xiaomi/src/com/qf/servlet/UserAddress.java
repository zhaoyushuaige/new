package com.qf.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.bean.Address;
import com.qf.bean.User;
import com.qf.service.UserService;
import com.qf.service.impl.UserServiceImpl;
@WebServlet("/userAddress")
public class UserAddress extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		User user = (User)req.getSession().getAttribute("loginUser");
		String flag = req.getParameter("flag");
		System.out.println(flag);
		
		UserService service = new UserServiceImpl();
		if(user!=null){
			if("default".equals(flag)){
				String addresssId = req.getParameter("id");
				System.out.println("addresssId:::"+addresssId);
				System.out.println("userId:"+user.getId());
				
				//���� ����ΪĬ�� �ķ��� ���� addressid �� userid
				if(service.defaultAddress(Integer.parseInt(addresssId),user.getId())){
					flag = "show";
				}
			}
			if("update".equals(flag)){
				String name = req.getParameter("name");
				String phone = req.getParameter("phone");
				String detail = req.getParameter("detail");
				String id = req.getParameter("id");
				String level = req.getParameter("level");
				
				//��������
				Address address = new Address(detail, name, phone, user.getId(), Integer.parseInt(level));
				address.setId(Integer.parseInt(id));
				if(service.updateAddress(address)){
					flag = "show";
				}
			}
			if("add".equals(flag)){
				String name = req.getParameter("name");
				String phone = req.getParameter("phone");
				String detail = req.getParameter("detail");
				//�������� Ĭ�ϵ�ַ�ȼ�  0
				Address address = new Address(detail, name, phone, user.getId(), 0);
				boolean b = service.addAddress(address);
				req.getRequestDispatcher("userAddress?flag=show").forward(req, resp);
			}
			if("delete".equals(flag)){
				System.out.println(flag);
				String id = req.getParameter("id");
				if(service.deleteAddress(Integer.parseInt(id))){
					flag = "show";
				}
			}
			if("show".equals(flag)){
				List<Address> list = service.getAddressList(user.getId());
				if(list!=null){
					req.getSession().setAttribute("addList", list);
				}
				resp.sendRedirect("self_info.jsp");
			}
		}else{
			resp.sendRedirect("login.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
