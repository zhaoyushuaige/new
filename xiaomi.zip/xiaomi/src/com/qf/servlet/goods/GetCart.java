package com.qf.servlet.goods;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.bean.BuyGoods;
import com.qf.bean.User;
import com.qf.service.CartService;
import com.qf.service.impl.CartServiceImpl;
@WebServlet("/getCart")
public class GetCart extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User user = (User)req.getSession().getAttribute("loginUser");
		if(user!=null){
			CartService service = new CartServiceImpl();
			List<BuyGoods> list = service.getAll(user.getId());
			if(list!=null){
				req.getSession().setAttribute("carts", list);
			}else{
				System.out.println("û���ҵ� ���ﳵ ");
			}
			req.getRequestDispatcher("cart.jsp").forward(req, resp);
		}else{
			resp.sendRedirect("login.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
