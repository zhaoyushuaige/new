package com.qf.servlet.goods;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.bean.GoodsType;
import com.qf.service.impl.GoodsServiceImpl;
@WebServlet("/addGoodsType")
public class AddGoodsType extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String typename = req.getParameter("typename");
		String parent = req.getParameter("goodsParent");
		
		GoodsType type = new GoodsType();
		
		if(parent!=null){
			type.setParent(Integer.parseInt(parent));
			type.setLevel(Integer.parseInt(parent)+1);
		}else{
			type.setLevel(1);
		}
		type.setName(typename);
		boolean res = new GoodsServiceImpl().addGoodsType(type);
		if(res){
			resp.sendRedirect("getGoodsType?flag=show");
		}else{
			resp.sendRedirect("admin.jsp");
		}
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
