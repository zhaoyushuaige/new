package com.qf.servlet.goods;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;

import com.mchange.v2.beans.BeansUtils;
import com.qf.bean.Goods;
import com.qf.service.GoodsService;
import com.qf.service.impl.GoodsServiceImpl;

@WebServlet("/addGoods")
public class AddGoods extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//������Ʒ��Ϣ
		Goods goods = new Goods();
		GoodsService service = new GoodsServiceImpl();
		
		//����map��� ��װ����
		Map<String, String[]> map = new HashMap<String,String[]>();

		try {
			//1.��������
			DiskFileItemFactory factory = new DiskFileItemFactory();
			//2.������
			ServletFileUpload upload = new ServletFileUpload(factory);
			//3.�õ�����
			List<FileItem> items = upload.parseRequest(req);
			
			for(FileItem item : items){
				if(item.isFormField()){
					//��ȡ������ǩ��
					String name = item.getFieldName();
					//ֵ
					String value = item.getString("utf-8");
					//�� ��ǩ�� �� ֵ ���뵽map������
					map.put(name, new String[]{value});
				}else{
					//�ϴ���ǩ
					//1.�����洢���ļ���
					String uploadPath = "d:\\1000phone\\xiaomi\\imgs\\";
					File storePath = new File(uploadPath);
					if(!storePath.exists()){
						storePath.mkdirs();
					}
					//2.��ȡ�ļ��ϴ���
					String fileName = item.getName();
					if(fileName!=null){
						fileName = FilenameUtils.getName(fileName);
					}
					//3.��ɢ���� �� Ŀ¼
					fileName = UUID.randomUUID()+"_"+fileName;
					//��������Ŀ¼
					String path = makeDir(storePath,fileName);
					fileName = path + File.separator + fileName;
					//4.���뵽������Ӳ��
					File file = new File(storePath,fileName);
					item.write(file);
					//�� ͼƬ���� map������
					map.put(item.getFieldName(), new String[]{fileName});
				}
			}
			//�� map���ϴ��뵽goods ������
			BeanUtils.populate(goods, map);
			boolean b = service.addGoods(goods);
			if(b){
				req.getRequestDispatcher("getGoodsList").forward(req, resp);
			}else{
				req.getSession().setAttribute("msg", "��Ʒ����ʧ��");
				resp.sendRedirect("admin/admin.jsp");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//��������Ŀ¼
	private String makeDir(File storePath, String fileName) {
		//��ȡ�ļ����Ĺ�ϣ��
		int code = fileName.hashCode();
		fileName = Integer.toHexString(code);
		//��ȡĿ¼�ṹ
		String str = fileName.charAt(0)+File.separator+fileName.charAt(1);
		File file = new File(storePath, str);
		if(!file.exists()){
			file.mkdirs();
		}
		return str;
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
