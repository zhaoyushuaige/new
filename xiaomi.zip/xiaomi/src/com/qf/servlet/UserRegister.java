package com.qf.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.bean.User;
import com.qf.service.UserService;
import com.qf.service.impl.UserServiceImpl;
import com.qf.utils.EmailUtils;
import com.qf.utils.MD5Utils;
import com.qf.utils.RandomUtils;
@WebServlet("/userRegister")
public class UserRegister extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String email = req.getParameter("email");
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String gender = req.getParameter("gender");
		// flag 0 ����δ���� role ��ɫ 1������Ա 
		// password ��Ҫ����
		// code ������ ������֤ �� ����Ҫ����
		User user = new User(0, 1, username, MD5Utils.md5(password), email, gender, RandomUtils.createActive());
		UserService service = new UserServiceImpl();
		if(service.addUser(user)){
			req.getSession().setAttribute("registerUser", user);
			//���ͼ����ʼ�
			EmailUtils.sendEmail(user);
			//����ע��ɹ�ҳ��
			resp.sendRedirect("registerSuccess.jsp");
		}else{
			req.getSession().setAttribute("registerMsg", "ע��ʧ��");
			resp.sendRedirect("register.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
