package com.qf.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.service.UserService;
import com.qf.service.impl.UserServiceImpl;
import com.qf.utils.Base64Utils;

//���� ����
@WebServlet("/activate")
public class UserActivate extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email = req.getParameter("e");
		String code = req.getParameter("c");
		if(email !=null && code !=null){
			UserService service = new UserServiceImpl();
			System.out.println("email::"+Base64Utils.decoder(email));
			System.out.println("code:::"+Base64Utils.decoder(code));
			if(service.activate(Base64Utils.decoder(email), Base64Utils.decoder(code))){
				//�������true  ֤�� �޸ĳɹ�
				resp.sendRedirect("login.jsp");
			}else{
				System.out.println("����ʧ��");
			}
		}else{
			System.out.println("�����쳣");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
