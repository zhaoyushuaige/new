package com.qf.dao.impl;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.qf.bean.Goods;
import com.qf.bean.GoodsType;
import com.qf.dao.GoodsDao;
import com.qf.utils.C3P0Utils;


public class GoodsDaoImpl implements GoodsDao {
	QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource());
	@Override
	public List<GoodsType> getGoodsTypeList() {
		String sql = "SELECT  gta.*,gtb.name parentName FROM tb_goods_type gta LEFT JOIN tb_goods_type gtb ON gta.parent = gtb.id";
		try {
			List<GoodsType> list = qr.query(sql, new BeanListHandler<GoodsType>(GoodsType.class));
			if(list!=null){
				return list;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public boolean addGoodsType(GoodsType gtype) {
		String sql = "insert into tb_goods_type(name,level,parent) values(?,?,?)";
		try {
			int res = qr.update(sql, gtype.getName(),gtype.getLevel(),gtype.getParent());
			if(res>0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public List<Goods> getGoodsList() {
		String sql = "select tb_goods_type.name as typeName,tb_goods.* from tb_goods,tb_goods_type where tb_goods_type.id = tb_goods.typeid";
		try {
			List<Goods> list = qr.query(sql, new BeanListHandler<Goods>(Goods.class));
			if(list!=null){
				return list;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public boolean addGoods(Goods goods) {
		
		try {
			String d = goods.getPubdate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse(d);
			
			String sql = "insert into tb_goods(name,pubdate,picture,price,star,intro,typeid) values(?,?,?,?,?,?,?)";
		
			int res = qr.update(sql, goods.getName(),new java.sql.Date(date.getTime()),goods.getPicture(),goods.getPrice(),goods.getStar(),goods.getIntro(),goods.getTypeid());
			if(res>0){
				return true;
			}
		
		} catch (ParseException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}
	@Override
	public List<GoodsType> getGoodsTypeAjaxList() {
		try {
			List<GoodsType> list = qr.query("select * from tb_goods_type where level = 1", new BeanListHandler<GoodsType>(GoodsType.class));
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public List<Goods> getGoodsListByTypeId(int typeId) {
		String sql = "SELECT tg.*,tgt.name typeName FROM tb_goods tg,tb_goods_type tgt WHERE tg.typeid = tgt.id";
		if(typeId>0){
			sql += " AND tg.typeid =" + typeId;
		}
		System.out.println(sql);
		try {
			List<Goods> list = qr.query(sql, new BeanListHandler<Goods>(Goods.class));
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public Goods getGoodsById(int goodsId) {
		String sql = "SELECT tg.*,tgt.name typeName FROM tb_goods tg,tb_goods_type tgt WHERE tg.typeid = tgt.id and tg.id=?";
		try {
			Goods goods = qr.query(sql, new BeanHandler<Goods>(Goods.class),goodsId);
			return goods;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}

















